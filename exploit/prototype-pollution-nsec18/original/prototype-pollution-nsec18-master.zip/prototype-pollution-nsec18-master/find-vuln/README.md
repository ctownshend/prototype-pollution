## Information

This is the minimal fuzzer that's described in the paper. Make sure that the library you want to test is installed before running it.

## Usage

> ./find-vuln.sh [LIBRARY_NAME]